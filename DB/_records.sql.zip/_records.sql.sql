-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               5.6.37 - MySQL Community Server (GPL)
-- Server OS:                    Win32
-- HeidiSQL Version:             9.4.0.5125
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Dumping structure for table test3.migrations
CREATE TABLE IF NOT EXISTS `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Dumping data for table test3.migrations: ~2 rows (approximately)
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` (`migration`, `batch`) VALUES
	('2014_10_12_000000_create_users_table', 1),
	('2014_10_12_100000_create_password_resets_table', 1),
	('2017_10_07_120728_create_records_table', 1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;

-- Dumping structure for table test3.password_resets
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL,
  KEY `password_resets_email_index` (`email`),
  KEY `password_resets_token_index` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Dumping data for table test3.password_resets: ~0 rows (approximately)
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;

-- Dumping structure for table test3.records
CREATE TABLE IF NOT EXISTS `records` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `desc` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `pub_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `author_id` int(11) NOT NULL DEFAULT '0',
  `image` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Dumping data for table test3.records: ~3 rows (approximately)
/*!40000 ALTER TABLE `records` DISABLE KEYS */;
INSERT INTO `records` (`id`, `title`, `desc`, `pub_date`, `author_id`, `image`) VALUES
	(7, 'Title 1', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean consectetur augue et orci aliquet lacinia. Nullam nec ex placerat justo maximus vulputate vitae sit amet massa. Integer consequat sagittis lorem, et consectetur dui pellentesque at. Nam ', '2017-10-15 21:20:07', 1, NULL),
	(8, 'Title 2', 'Etiam at ipsum dolor. Proin tincidunt, lectus et aliquam tristique, nulla augue tincidunt odio, a hendrerit odio sem vel tortor. Aliquam nisl orci, euismod nec massa sit amet, interdum faucibus quam. Nulla tincidunt erat eros, in luctus dui placerat ', '2017-10-15 21:20:21', 2, 'img_59e3a6e5603d2.jpeg'),
	(9, 'Title 3', 'Vivamus imperdiet condimentum euismod. Integer tincidunt auctor diam iaculis facilisis. Cras sapien nisi, congue nec lacus a, condimentum elementum libero. Sed suscipit urna sit amet dolor luctus laoreet. Nunc magna purus, vulputate ac egestas ut, rh', '2017-10-15 21:20:40', 1, 'img_59e3a7481dc66.jpeg');
/*!40000 ALTER TABLE `records` ENABLE KEYS */;

-- Dumping structure for table test3.users
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `last_login` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Dumping data for table test3.users: ~0 rows (approximately)
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `name`, `email`, `password`, `remember_token`, `created_at`, `updated_at`, `last_login`) VALUES
	(1, 'test', 't@t.t', '$2y$10$qIKU/YQJ2ssiYjfdj1fCk.e6UZbmoruPXckHsRUf1xgthtFPh1Wyy', 'cCct1GesZSObRZ0c1nY9WMR0cdAfdykZZ1MuAkOe7cvivAQ6fOCmmhOvgU6T', '2017-10-14 19:07:35', '2017-10-15 17:59:46', '2017-10-15 17:59:46'),
	(2, 'Test2', 't2@t.t', '$2y$10$zd/Z7DvkOXhi8GqurSaphu9OF4wgvfw1toK/UK4AOJxmxnnwfjYaG', NULL, '2017-10-15 01:44:29', '2017-10-15 01:44:29', '2017-10-15 01:44:29');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
